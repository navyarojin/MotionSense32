#define I_SDA 8
#define I_SCL 9

#define S_CS  5
#define S_MISO 10
#define S_MOSI 11
#define S_SCK  12

#define U_TX  43
#define U_RX  44

#define LED   48
